from tkinter import*
from tkinter import ttk
from tkinter import messagebox
from PIL import Image, ImageTk
from Unimark_Student import Student
import os
from Unimark_train_ai import TrainAI
from Unimark_Face_Recog import Face_Recognition
from Unimark_Attendance import Attendance


class Unimark:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1530x790+0+0")
        self.root.title("UniMark")

        img=Image.open(r"C:\NUST\1ST Semester\ICT\End Semester Project\Images for GUI\background image.jpg")
        img = img.resize((1536, 790), Image.Resampling.LANCZOS)

        self.photoimg=ImageTk.PhotoImage(img)

        f_lbl=Label(self.root,image=self.photoimg)
        f_lbl.place(x=0,y=0,width=1536,height=700)

        bg_img=Label(self.root,image=self.photoimg)
        bg_img.place(x=0,y=130,width=1536,height=700)

        title_lbl=Label(bg_img, text="      UNIMARK - FACIAL RECOGNITION ATTENDANCE MANAGEMENT SYSTEM    ", \
                        font = ("aptos display",31,"bold"), bg="light cyan", fg="midnight blue") 
        title_lbl.place(x=(1530 - title_lbl.winfo_reqwidth()) // 2, y=10) 
        
        #student details
        img4=Image.open(r"C:\NUST\1ST Semester\ICT\End Semester Project\Images for GUI\Students detail.png")
        img4=img4.resize((220,220),Image.Resampling.LANCZOS)
        self.photoimg4=ImageTk.PhotoImage(img4)

        b1=Button(bg_img, image=self.photoimg4,command=self.student_details,cursor="hand2")
        b1.place(x=100,y=210,width=220,height=220)

        b1_1=Button(bg_img, text="Student Details",command=self.student_details, cursor="hand2",font=("cambria",15,"bold"),bg="antique white" , fg ="midnight blue")
        b1_1.place(x=100,y=410,width=220,height=40)

        #face recognition
        img5=Image.open(r"C:\NUST\1ST Semester\ICT\End Semester Project\Images for GUI\face recog.png")
        img5=img5.resize((220,220),Image.Resampling.LANCZOS)
        self.photoimg5=ImageTk.PhotoImage(img5)

        b1=Button(bg_img, image=self.photoimg5,cursor="hand2", command=self.face_recognition)
        b1.place(x=370,y=210,width=220,height=220)

        b1_1=Button(bg_img, text="Facial Recognition", cursor="hand2",command=self.face_recognition,font=("cambria",15,"bold"),bg="antique white" , fg ="midnight blue")
        b1_1.place(x=370,y=410,width=220,height=40)
        
        #attendance
        img6=Image.open(r"C:\NUST\1ST Semester\ICT\End Semester Project\Images for GUI\attendance.png")
        img6=img6.resize((220,220),Image.Resampling.LANCZOS)
        self.photoimg6=ImageTk.PhotoImage(img6)

        b1=Button(bg_img, image=self.photoimg6,cursor="hand2",command=self.attendance)
        b1.place(x=640,y=210,width=220,height=220)

        b1_1=Button(bg_img, text="Attendance", cursor="hand2",command=self.attendance,font=("cambria",15,"bold"),bg="antique white" , fg ="midnight blue")
        b1_1.place(x=640,y=410,width=220,height=40)

        #train
        img8=Image.open(r"C:\NUST\1ST Semester\ICT\End Semester Project\Images for GUI\ai.png")
        img8=img8.resize((220,220),Image.Resampling.LANCZOS)
        self.photoimg8=ImageTk.PhotoImage(img8)

        b1=Button(bg_img, image=self.photoimg8,cursor="hand2",command=self.train_data)
        b1.place(x=910,y=210,width=220,height=220)

        b1_1=Button(bg_img, text="Train Model", cursor="hand2",command=self.train_data,font=("cambria",15,"bold"),bg="antique white" , fg ="midnight blue")
        b1_1.place(x=910,y=410,width=220,height=40)

        #exit
        img11=Image.open(r"C:\NUST\1ST Semester\ICT\End Semester Project\Images for GUI\exit.jpeg")
        img11=img11.resize((220,220),Image.Resampling.LANCZOS)
        self.photoimg11=ImageTk.PhotoImage(img11)

        b1=Button(bg_img, image=self.photoimg11,cursor="hand2",command=self.exit)
        b1.place(x=1180,y=210,width=220,height=220)

        b1_1=Button(bg_img, text="Exit", cursor="hand2",command=self.exit,font=("cambria",15,"bold"),bg="antique white" , fg ="midnight blue")
        b1_1.place(x=1180,y=410,width=220,height=40)

    #==== functions ====#
    def student_details(self):
        self.new_window=Toplevel(self.root)
        self.app=Student(self.new_window)

    def train_data(self):
        self.new_window=Toplevel(self.root)
        self.app=TrainAI(self.new_window)

    def face_recognition(self):
        self.new_window=Toplevel(self.root)
        self.app=Face_Recognition(self.new_window)

    def attendance(self):
        self.new_window=Toplevel(self.root)
        self.app=Attendance(self.new_window)
    
    def exit(self):
        self.exit=messagebox.askyesno("Unimark","Do you want to exit this window?")
        if self.exit > 0:
            self.root.destroy()
        else:
            return

if __name__ == "__main__":
    root=Tk()
    obj=Unimark(root)
    root.mainloop()