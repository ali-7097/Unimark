from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk
import mysql.connector
from time import strftime
from datetime import datetime
import cv2
import os
import threading

class Face_Recognition:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1530x790+0+0")
        self.root.title("UniMark")

        self.video_thread = None


        # Background Image
        img = Image.open(r"C:\NUST\1ST Semester\ICT\End Semester Project\Images for GUI\background image.jpg")
        img = img.resize((1536, 864), Image.Resampling.LANCZOS)
        self.photoimg = ImageTk.PhotoImage(img)

        bg_img = Label(self.root, image=self.photoimg)
        bg_img.place(x=0, y=0, width=1536, height=864)

        # Title Label
        title_lbl = Label(
            bg_img,
            text="Face Recognition",
            font=("aptos display", 31, "bold"),
            bg="light cyan",
            fg="midnight blue",
        )
        title_lbl.place(x=0, y=90, width=1536)

        # Image on Left
        img_left = Image.open(r"C:\NUST\1ST Semester\ICT\End Semester Project\Images for GUI\face.jpg")
        img_left = img_left.resize((325, 210), Image.Resampling.LANCZOS)
        self.model_img_left = ImageTk.PhotoImage(img_left)
        Label(bg_img, image=self.model_img_left).place(x=420, y=260)

        # Image on Right
        img_right = Image.open(r"C:\NUST\1ST Semester\ICT\End Semester Project\Images for GUI\facial recognition.jpg")
        img_right = img_right.resize((325, 210), Image.Resampling.LANCZOS)
        self.model_img_right = ImageTk.PhotoImage(img_right)
        Label(bg_img, image=self.model_img_right).place(x=745, y=260)

        # Start Button
        Button(
            self.root,
            text="Start Facial Recognition",
            command=self.start_recognition,
            cursor="hand2",
            font=("cambria", 28, "bold"),
            bg="steel blue",
            fg="white",
        ).place(x=422, y=476, width=655, height=210)

        #attendance
    def mark_attendance(self, name, cms, program, section):
        try:
            # Read the existing data to check if student info already exists
            with open(r"C:\NUST\1ST Semester\ICT\End Semester Project\unimark.csv", "r") as f:
                myDataList = f.readlines()
                name_list = []

                # Iterate through the data and extract the names for comparison
                for line in myDataList:
                    entry = line.strip().split(",")  # Use strip to avoid whitespace issues
                    name_list.append(entry[0])  # Assuming name is the first field

            # Check if the student is not already in the attendance list
            if cms not in name_list and name not in name_list and program not in name_list and section not in name_list:
                # Open the file in append mode to add attendance data
                with open(r"C:\NUST\1ST Semester\ICT\End Semester Project\unimark.csv", "a") as f:
                    now = datetime.now()
                    d1 = now.strftime("%d/%m/%Y")  # Corrected format for day/month/year
                    dtstring = now.strftime("%H:%M:%S")  # Current time

                    # Write new attendance data
                    f.writelines(f"\n{name},{program},{cms},{section},{d1},{dtstring},Present")

                print("Attendance marked successfully.")
            else:
                print("This student is already marked present.")

        except Exception as e:
            print(f"Error while marking attendance: {e}")
        
    

    def start_recognition(self):
        if not self.video_thread:
            self.video_thread = threading.Thread(target=self.face_recog)
            self.video_thread.start()
    def face_recog(self):
        def draw_boundary(img, classifier, scaleFactor, minNeighbors, clf):
            gray_image = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            features = classifier.detectMultiScale(gray_image, scaleFactor, minNeighbors)
            print(f"Detected features: {features}")
            
            for (x, y, w, h) in features:
                cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 3)
                id, predict = clf.predict(gray_image[y:y + h, x:x + w])
                confidence = 100 if predict == 0 else int((100 * (1 - predict / 300)))
                print(f"Predicted ID: {id}, Confidence Value: {predict}")
                print(id)

                try:
                    # Connect to the MySQL database
                    with mysql.connector.connect(host="localhost", username="root", password="new_password", database="unimark") as conn:
                        my_cursor = conn.cursor()
                        # Use parameterized query to prevent SQL injection
                        my_cursor.execute("SELECT name, cms, program, section FROM details WHERE cms = %s", (str(id),))
                        result = my_cursor.fetchone()
                        
                        if result:
                            name, cms, program, section = result
                        else:
                            name, cms, program, section = "Unknown", "Unknown", "Unknown", "Unknown"
                except mysql.connector.Error as e:
                    name, cms, program, section = "Error", "Error", "Error", "Error"
                    print(f"Database error: {e}")

                # If the confidence is sufficient, mark attendance
                if confidence > 40:
                    cv2.putText(img, f"Name: {name}", (x, y - 85), cv2.FONT_HERSHEY_COMPLEX, 0.8, (255, 255, 255), 3)
                    cv2.putText(img, f"CMS ID: {cms}", (x, y - 55), cv2.FONT_HERSHEY_COMPLEX, 0.8, (255, 255, 255), 3)
                    cv2.putText(img, f"Program: {program}", (x, y - 25), cv2.FONT_HERSHEY_COMPLEX, 0.8, (255, 255, 255), 3)
                    cv2.putText(img, f"Section: {section}", (x, y - 5), cv2.FONT_HERSHEY_COMPLEX, 0.8, (255, 255, 255), 3)
                    self.mark_attendance(name, cms, program, section)
                else:
                    cv2.putText(img, "Unknown", (x, y - 5), cv2.FONT_HERSHEY_COMPLEX, 0.8, (255, 255, 255), 3)

        def recognize(img, clf, faceCascade):
            draw_boundary(img, faceCascade, 1.1, 10, clf)
            return img

        face_cascade = cv2.CascadeClassifier(r"C:\NUST\1ST Semester\ICT\End Semester Project\haarcascade_frontalface_default.xml")
        clf = cv2.face.LBPHFaceRecognizer_create()
        clf.read(r"C:\NUST\1ST Semester\ICT\End Semester Project\classifier.xml")

        if clf.empty():
            print("Error: Classifier could not be loaded!")
        else:
            print("Classifier loaded successfully!")

        video_cap = cv2.VideoCapture(0)

        while True:
            ret, img = video_cap.read()
            if not ret:
                break

            img = recognize(img, clf, face_cascade)
            cv2.imshow("Face Recognition", img)

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        video_cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    root = Tk()
    app = Face_Recognition(root)
    root.mainloop()



