from tkinter import*
from tkinter import ttk
from PIL import Image, ImageTk
from tkinter import messagebox
import mysql.connector
import cv2
import os
import numpy as np

class TrainAI:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1530x790+0+0")
        self.root.title("UniMark")

        # Background Image
        img = Image.open(r"C:\NUST\1ST Semester\ICT\End Semester Project\Images for GUI\\background image.jpg")
        img = img.resize((1536, 864), Image.Resampling.LANCZOS)
        self.photoimg = ImageTk.PhotoImage(img)

        f_lbl = Label(self.root, image=self.photoimg)
        f_lbl.place(x=0, y=0, width=1536, height=700)

        bg_img = Label(self.root, image=self.photoimg)
        bg_img.place(x=0, y=90, width=1536, height=700)

        # Title Label
        title_lbl = Label(bg_img, text="Train AI Model", font=("aptos display", 31, "bold"), bg="Light cyan", fg="midnight blue")
        title_lbl.place(x=0, y=10, width=1536)

        # Add an Image between the Label and Button
        img_left = Image.open(r"C:\NUST\1ST Semester\ICT\End Semester Project\Images for GUI\train ai6.jpg")
        img_left = img_left.resize((325, 210), Image.Resampling.LANCZOS)
        self.model_img_left = ImageTk.PhotoImage(img_left)
        model_lbl = Label(bg_img, image=self.model_img_left)
        model_lbl.place(x=420,y=170)

        img_right = Image.open(r"C:\NUST\1ST Semester\ICT\End Semester Project\Images for GUI\train ai7.jpg")
        img_right = img_right.resize((325, 210), Image.Resampling.LANCZOS)
        self.model_img = ImageTk.PhotoImage(img_right)
        model_lbl = Label(bg_img, image=self.model_img)
        model_lbl.place(x=745,y=170)

        # Button
        b1_1 = Button(self.root, text="Train AI Model Via Data Set", command=self.train_classifier, cursor="hand2", font=("cambria", 20, "bold"), bg="steel blue", fg="white")
        b1_1.place(x=422, y=476, width=655, height=210)

    def train_classifier(self):
        data_dir = (r"C:\NUST\1ST Semester\ICT\End Semester Project\Data")
        if not os.path.exists(data_dir):
            messagebox.showerror("Error", "Data directory not found!")
            return

        path = [os.path.join(data_dir, file) for file in os.listdir(data_dir)]
        faces = []
        ids = []

        for image in path:
            try:
                img = Image.open(image).convert('L')  # Grayscale image
                image_np = np.array(img, 'uint8')
                id = int(os.path.split(image)[1].split('.')[1])  # Extract ID from file name
                faces.append(image_np)
                ids.append(id)
            except Exception as e:
                print(f"Error processing file {image}: {e}")

        if len(faces) == 0 or len(ids) == 0:
            messagebox.showerror("Error", "No valid training data found!")
            return

        ids = np.array(ids)

        try:
            # Train the classifier and save
            clf = cv2.face.LBPHFaceRecognizer_create()
            clf.train(faces, ids)
            clf.write(r"C:\NUST\1ST Semester\ICT\End Semester Project\classifier.xml")
            cv2.destroyAllWindows()
            messagebox.showinfo("Result", "Trained datasets successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Training failed: {e}")

if __name__ == "__main__":
    root = Tk()
    obj = TrainAI(root)
    root.mainloop()
