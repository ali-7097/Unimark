from tkinter import *
from tkinter import ttk
from tkinter import filedialog
from tkinter import messagebox
from PIL import Image, ImageTk
import mysql.connector
from time import strftime
from datetime import datetime
import cv2
import os
import csv

mydata = []


class Attendance:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1530x790+0+0")
        self.root.title("UniMark")

        self.video_thread = None


        # Background Image
        img = Image.open(r"C:\NUST\1ST Semester\ICT\End Semester Project\Images for GUI\background image.jpg")
        img = img.resize((1536, 864), Image.Resampling.LANCZOS)
        self.photoimg = ImageTk.PhotoImage(img)

        bg_img = Label(self.root, image=self.photoimg)
        bg_img.place(x=0, y=0, width=1536, height=864)

        # Title Label
        title_lbl = Label(
            bg_img,
            text="Attendance Management",
            font=("aptos display", 31, "bold"),
            bg="light cyan",
            fg="midnight blue",
        )
        title_lbl.place(x=0, y=90, width=1536)

         #main frame
        main_frame=Frame(bg_img,bd=2,bg="darkslate gray")
        main_frame.place(x=20,y=165,width=1480,height=600)
        
         #=table frame=
        table_frame=Frame(main_frame,bd=2,bg="light cyan",relief=RIDGE)
        table_frame.place(x=10,y=10,width=1450,height=510)

        scroll_x=ttk. Scrollbar(table_frame, orient=HORIZONTAL)
        scroll_y=ttk. Scrollbar(table_frame,orient=VERTICAL)

        self.attendance_table=ttk. Treeview(table_frame, column=("name","program","cms","section","date","time","attendance"),\
        xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)

        scroll_x.pack(side=BOTTOM,fill=X)
        scroll_y.pack(side=RIGHT,fill=Y)

        scroll_x.config(command=self.attendance_table.xview)
        scroll_y.config(command=self.attendance_table.yview)

        self.attendance_table.heading("name",text="Name")
        self.attendance_table.heading("program",text="Program")
        self.attendance_table.heading("cms",text="CMS ID")
        self.attendance_table.heading("section",text="Section")
        self.attendance_table.heading("date",text="Date")
        self.attendance_table.heading("time",text="Time")
        self.attendance_table.heading("attendance",text="Attendance Status")
        self.attendance_table["show"]="headings"


        self.attendance_table.column("name",width=150)
        self.attendance_table.column("program",width=150)   
        self.attendance_table.column("cms",width=100)    
        self.attendance_table.column("section",width=70)
        self.attendance_table.column("date",width=100)
        self.attendance_table.column("time",width=100)
        self.attendance_table.column("attendance",width=100)

        self.attendance_table.pack(fill=BOTH,expand=1)

        #bottom table frame
        bottom_frame=LabelFrame(main_frame,bd=2,bg="light cyan",relief=RIDGE)
        bottom_frame.place(x=10,y=530,width=1450,height=60)

        #import button
        import_btn=Button(bottom_frame, text="Import Data",command=self.import_data,width=17,font=("cambria",13,"bold"),bg="midnight blue", fg = "light cyan")
        import_btn.place(x=10,y=10,width=715)

        #export button
        export_btn=Button(bottom_frame, text="Export Data",command=self.export_data,width=17,font=("cambria",13,"bold"),bg="midnight blue", fg = "light cyan")
        export_btn.place(x=725,y=10,width=715)

    #fetch data from csv file
    def fetch_data(self,rows):
        self.attendance_table.delete(*self.attendance_table.get_children())
        for i in rows:
            self.attendance_table.insert("",END,values=i)

    #import csv
    def import_data(self):
        global mydata
        mydata.clear()
        file_name=filedialog.askopenfilename(initialdir=os.getcwd(),title="Open CSV",filetypes=(("CSV File","*csv"),("All file","*.*")),parent=self.root)
        with open(file_name) as myfile:
            csvread=csv.reader(myfile,delimiter=",")
            for i in csvread:
                mydata.append(i)
            self.fetch_data(mydata)

    #export csv
    def export_data(self):
        try:
            if len(mydata)<1:
                messagebox.showerror("No Data","No data found to export",parent=self.root)
                return False
            file_name=filedialog.asksaveasfilename(initialdir=os.getcwd(),title="Open CSV",filetypes=(("CSV File","*csv"),("All file","*.*")),parent=self.root)
            with open(file_name,mode="w",newline="") as myfile:
                export_write = csv.writer(myfile,delimiter=",")
                for i in mydata:
                    export_write.writerow(i)
                messagebox.showinfo("Data Export","Your Data Exported to "+os.path.basename(file_name)+" Succcesfully")
        except Exception as es: 
            messagebox.showerror("ERROR",f"Due To :{str(es)}",parent=self.root)

if __name__ == "__main__":
    root=Tk()
    obj=Attendance(root)
    root.mainloop()